$(document).ready(function(){

    function planet(name,size,color,duration){
        $(name).css({width:size+"px", height:size+"px", color:color});
        $(name).children("span").css({fontSize:size/1.3+"px"});
        var w = $(name).children("span").width();
        $(name).children(".txt").css({marginLeft:-1*w+"px"});
        $(name).children(".txtrev").css({marginLeft:size+"px"});
        frontmove(name,duration,size,w);
    }
    
    function frontmove(who,duration,size,w){
        $(who).children(".txt").animate({
            marginLeft: size+w+"px"
        },{
            duration: duration,
            easing: "linear",
            step: function(now, fx){
                $(who).children(".txtrev").css({
                    marginLeft:size-now+"px"
                });
            },
            complete: function(){
                $(this).css({marginLeft:-1*w+"px"});
                frontmove(who,duration,size,w);
            }
        });
    };
    
    planet(".p1",200,"white",4000);
    
});